DROP DATABASE if EXISTS friends;
create DATABASE friends;
use friends;


CREATE TABLE animals_type(
	id SERIAL PRIMARY KEY,
	`name` VARCHAR(150)
);

INSERT INTO animals_type (id, `name`) 
VALUES (1, 'Домашние'), (2, 'Вьючные');


CREATE TABLE cat(
	`name` VARCHAR(15),
    bith DATE not null,
    command VARCHAR(25),
    animal_type BIGINT UNSIGNED NOT NULL,
    FOREIGN KEY (animal_type) REFERENCES animals_type(id) ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO cat (`name`, bith, command, animal_type) 
VALUES ('Маруся', '2000-01-01', 'мяууу', 1), ('пушистек', '2022-01-01', 'царапать', 1);

CREATE TABLE dog(
	`name` VARCHAR(15),
    bith DATE not null,
    command VARCHAR(25),
    animal_type BIGINT UNSIGNED NOT NULL,
    FOREIGN KEY (animal_type) REFERENCES animals_type(id) ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO dog (`name`, bith, command, animal_type) 
VALUES ('Рекс', '2000-01-01', 'гав-гав', 1), ('Шпиц', '2000-01-01', 'сидеть', 1);

CREATE TABLE horse(
	`name` VARCHAR(15),
    bith DATE not null,
    command VARCHAR(25),
    animal_type BIGINT UNSIGNED NOT NULL,
    FOREIGN KEY (animal_type) REFERENCES animals_type(id) ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO horse (`name`, bith, command, animal_type) 
VALUES ('Мустанг', '2020-01-01', 'легнуть копытом', 2);

CREATE TABLE verblud(
	`name` VARCHAR(15),
    bith DATE not null,
    command VARCHAR(25),
    animal_type BIGINT UNSIGNED NOT NULL,
    FOREIGN KEY (animal_type) REFERENCES animals_type(id) ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO verblud (`name`, bith, command, animal_type) 
VALUES ('Ляля', '2000-01-01', 'пускать слюни', 2);

CREATE TABLE osel(
	`name` VARCHAR(15),
    bith DATE not null,
    command VARCHAR(25),
    animal_type BIGINT UNSIGNED NOT NULL,
    FOREIGN KEY (animal_type) REFERENCES animals_type(id) ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO osel (`name`, bith, command, animal_type) 
VALUES ('Осел1', '2022-01-01', 'тупить', 2);

CREATE TABLE homyak(
	`name` VARCHAR(15),
    bith DATE not null,
    command VARCHAR(25),
    animal_type BIGINT UNSIGNED NOT NULL,
    FOREIGN KEY (animal_type) REFERENCES animals_type(id) ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO homyak (`name`, bith, command, animal_type) 
VALUES ('Хомяк1', '2021-01-01', 'грызть', 1);

delete from verblud;

create table packAnimalNew (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY)
select  `name`, 
        command, 
        bith
from horse union 
select  `name`, 
        command, 
        bith
from osel;

-- select * from packAnimalNew;

create table pet (
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(45),
    command VARCHAR(45),
    bith DATE
);

create table humanFriend(
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(45),
    command VARCHAR(45),
    bith DATE
    );
    
    
INSERT into pet (`name`, command, bith)
select  `name`, 
        command, 
        bith
from cat union 
select  `name`, 
        command, 
        bith
from dog union
select  `name`, 
        command, 
        bith
from homyak;
select * from pet;

INSERT into humanFriend (`name`, command, bith)
select  `name`, 
        command, 
        bith
from pet union 
select  `name`, 
        command, 
        bith
from packAnimalNew;

-- select * from humanFriend;


create table youngAnimals (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY)
select `name`, 
        command, 
        bith,
        Round((year(current_date()) - year(bith)) + (month(current_date() - month(bith)))/10, 2) as age
from humanFriend
where Round((year(current_date()) - year(bith)) + (month(current_date() - month(bith)))/10, 2) > 1 
	and Round((year(current_date()) - year(bith)) + (month(current_date() - month(bith)))/10, 2) < 3;
-- select * from youngAnimals;

create table newhumanFriend (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY)
select  `name`, 
        command, 
        bith,
        'cat' as oldTable
from cat union 
select  `name`, 
        command, 
        bith,
        'dog' as oldTable
from dog union
select  `name`, 
        command, 
        bith,
        'homyak' as oldTable
from homyak union 
select  `name`, 
        command, 
        bith,
        'horse' as oldTable
from horse union 
select  `name`, 
        command, 
        bith,
        'osel' as oldTable
from osel;

select * from newhumanFriend;

insert newhumanFriend(`name`, command, bith)
VALUEs ('ляля', 'lejat', '2000-01-01');
select * from newhumanFriend;
